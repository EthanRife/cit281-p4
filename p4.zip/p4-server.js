/*
    CIT 281 Project 4
    Name: Ethan Rife
*/

// Import module files
const fs = require("fs");
const fastify = require("fastify")();
const { getAnswer, getAnswers, getQuestion, getQuestionAnswer, getQuestionsAnswers, getQuestions } = require("./p4-module.js");

fastify.get("/cit/question", (request, reply) => {
    // 1 )  Get information from the request
    // 2) Process information
    // Get all the questions

    const questionsToReturn = getQuestions();
    const resultToReturn = JSON.stringify(questionsToReturn);
    // 3) Provide a reply to the client.
    // Provide all the questions from (2) to the client.
    reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send(resultToReturn);
});

fastify.get("/cit/answer", (request, reply) => {
    const answerToReturn = getAnswers();
    const resultToReturn = JSON.stringify(answerToReturn);
    reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send(resultToReturn);
});

fastify.get("/questionanswer", (request, reply) => {
    const questionAnswerToReturn = getQuestionsAnswers();
    const resultToReturn = JSON.stringify(questionAnswerToReturn);
    reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send(resultToReturn);
});

fastify.get("/cit/question/:number", (request, reply) => {
    const { number } = request.params;
    const resultToReturn = getQuestion(parseInt(number));
    //resultToReturn.statusCode = 200;
    //console.log(resultToReturn);
    reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send({error: "", statuscode: 200, question: resultToReturn.question, number: number});
});

fastify.get("/cit/answer/:number", (request, reply) => {
    const { number } = request.params;
    const resultToReturn = getAnswer(parseInt(number));
    //resultToReturn.statusCode = 200;
    reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send({error: "", statuscode: 200, answer: resultToReturn.answer, number: number});
});

fastify.get("/cit/questionanswer/:number", (request, reply) => {
    const { number } = request.params;
    const resultToReturn = getQuestionAnswer(parseInt(number));
    //resultToReturn.statusCode = 200;
    reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send({error: "", statuscode: 200, question: resultToReturn.question, answer: resultToReturn.answer, number: number});
});

fastify.get("/*", (request, reply) => {
    const errorStatement = {
        "error": "Route not found",
        "statusCode": 404
    };
    const resultToReturn = JSON.stringify(errorStatement);
    reply
    .code(404)
    .header("Content-Type", "application/json; charset=utf-8")
    .send(resultToReturn);
});

// Start server and listen to requests using Fastify
const listenIP = "localhost";
const listenPort = 8080;
fastify.listen(listenPort, listenIP, (err, address) => {
  if (err) {
    console.log(err);
    process.exit(1);
  }
  console.log(`Server listening on ${address}`);
});